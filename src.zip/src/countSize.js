export default {
    computed: {
        countSize: function() {
            return `${this.text} (${this.text.length})`;
        }
    } 
}
